angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController.informeSe', {
    url: '/page2',
    views: {
      'tab1': {
        templateUrl: 'templates/informeSe.html',
        controller: 'informeSeCtrl'
      }
    }
  })

  .state('tabsController.alimentaO', {
    url: '/page3',
    views: {
      'tab2': {
        templateUrl: 'templates/alimentaO.html',
        controller: 'alimentaOCtrl'
      }
    }
  })

  .state('tabsController.evoluO', {
    url: '/page4',
    views: {
      'tab3': {
        templateUrl: 'templates/evoluO.html',
        controller: 'evoluOCtrl'
      }
    }
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.dOMINGO', {
    url: '/page7',
    views: {
      'tab2': {
        templateUrl: 'templates/dOMINGO.html',
        controller: 'dOMINGOCtrl'
      }
    }
  })

  .state('tabsController.sEGUNDA', {
    url: '/page22',
    views: {
      'tab2': {
        templateUrl: 'templates/sEGUNDA.html',
        controller: 'sEGUNDACtrl'
      }
    }
  })

  .state('tabsController.tERA', {
    url: '/page23',
    views: {
      'tab2': {
        templateUrl: 'templates/tERA.html',
        controller: 'tERACtrl'
      }
    }
  })

  .state('tabsController.qUARTA', {
    url: '/page24',
    views: {
      'tab2': {
        templateUrl: 'templates/qUARTA.html',
        controller: 'qUARTACtrl'
      }
    }
  })

  .state('tabsController.qUINTA', {
    url: '/page25',
    views: {
      'tab2': {
        templateUrl: 'templates/qUINTA.html',
        controller: 'qUINTACtrl'
      }
    }
  })

  .state('tabsController.sEXTA', {
    url: '/page26',
    views: {
      'tab2': {
        templateUrl: 'templates/sEXTA.html',
        controller: 'sEXTACtrl'
      }
    }
  })

  .state('tabsController.sBADO', {
    url: '/page27',
    views: {
      'tab2': {
        templateUrl: 'templates/sBADO.html',
        controller: 'sBADOCtrl'
      }
    }
  })

  .state('tabsController.comoSerMaisSaudVel', {
    url: '/page20',
    views: {
      'tab1': {
        templateUrl: 'templates/comoSerMaisSaudVel.html',
        controller: 'comoSerMaisSaudVelCtrl'
      }
    }
  })

  .state('tabsController.oQueComer', {
    url: '/page21',
    views: {
      'tab1': {
        templateUrl: 'templates/oQueComer.html',
        controller: 'oQueComerCtrl'
      }
    }
  })

  .state('tabsController.cafDaManh', {
    url: '/page28',
    views: {
      'tab1': {
        templateUrl: 'templates/cafDaManh.html',
        controller: 'cafDaManhCtrl'
      }
    }
  })

  .state('tabsController.lancheDaManh', {
    url: '/page29',
    views: {
      'tab1': {
        templateUrl: 'templates/lancheDaManh.html',
        controller: 'lancheDaManhCtrl'
      }
    }
  })

  .state('tabsController.almoO', {
    url: '/almoço',
    views: {
      'tab1': {
        templateUrl: 'templates/almoO.html',
        controller: 'almoOCtrl'
      }
    }
  })

  .state('tabsController.lancheDaTarde', {
    url: '/lanche tarde',
    views: {
      'tab1': {
        templateUrl: 'templates/lancheDaTarde.html',
        controller: 'lancheDaTardeCtrl'
      }
    }
  })

  .state('tabsController.janta', {
    url: '/janta',
    views: {
      'tab1': {
        templateUrl: 'templates/janta.html',
        controller: 'jantaCtrl'
      }
    }
  })

  .state('tabsController.lancheDaNoite', {
    url: '/lanche noite',
    views: {
      'tab1': {
        templateUrl: 'templates/lancheDaNoite.html',
        controller: 'lancheDaNoiteCtrl'
      }
    }
  })

  .state('tabsController.home', {
    url: '/page8',
    views: {
      'tab4': {
        templateUrl: 'templates/home.html',
        controller: 'homeCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/page2')


});